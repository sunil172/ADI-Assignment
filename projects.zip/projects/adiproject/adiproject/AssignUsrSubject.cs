﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adi.Classes
{
    public partial class AssignUsrSubject : Form
    {
        public AssignUsrSubject()
        {
            InitializeComponent();
        }

        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
        public void SubjectName()
        {
            cmbSubjectName.Items.Clear();
            DataSet ds = new DataSet();
            ds.Clear();
            //Connection String
            SqlConnection conn = new SqlConnection(myconnstring);

            conn.Open();
            SqlDataAdapter adpi = new SqlDataAdapter("Select distinct id,subjectname from Subject", conn);
            adpi.Fill(ds);
            cmbSubjectName.DataSource = ds.Tables[0];
            cmbSubjectName.DisplayMember = "subjectname";
            cmbSubjectName.ValueMember = "id";
            conn.Close();
        }

        public void UserName()
        {
            listUserName.DataSource = null;
            listUserName.Items.Clear();
            DataSet ds = new DataSet();
            ds.Clear();
            //Connection String
            SqlConnection conn = new SqlConnection(myconnstring);

            conn.Open();
            SqlDataAdapter adpi = new SqlDataAdapter("select distinct id, name from users where id not in(select distinct userid from user_subject);", conn);
            adpi.Fill(ds);
            listUserName.DataSource = ds.Tables[0];
            listUserName.DisplayMember = "name";
            listUserName.ValueMember = "id";
            conn.Close();
        }

        private void AssignUsrSubject_Load(object sender, EventArgs e)
        {
            SubjectName();
            UserName();
            DataTable dt = c.Select();
            dgvAssignSubject.DataSource = dt;
        }

        AssignUser c = new AssignUser();

        private void btnCreate_Click(object sender, EventArgs e)
        {
           
            bool success = false;
            c.subjectid = int.Parse(cmbSubjectName.SelectedValue.ToString());

            var lst = listUserName.SelectedItems.Cast<DataRowView>();
            foreach (var item in lst)
            {
              c.userid=int.Parse( item.Row[0].ToString());// Or Row[1]...
              //  MessageBox.Show(c.userid.ToString());

            success=c.Insert(c);
               // success = true;

            }

          
            if (success == true)
            {
                MessageBox.Show("Subject Assigned Successfully");
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To Add Subject");

            }

            DataTable dt = c.Select();
            dgvAssignSubject.DataSource = dt;


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            c.subjectid = int.Parse(textSubjectId.Text);
            c.userid = int.Parse(textUserId.Text);
            bool success = c.Delete(c);

            if (success == true)
            {
                MessageBox.Show("Relation Deleted Successfully");
                DataTable dt = c.Select();
                dgvAssignSubject.DataSource = dt;
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To Delete Relation");

            }
        }

        public void Clear()
        {

            cmbSubjectName.Text = "";
            textUserId.Text = "";
            textSubjectId.Text = "";
            UserName();


        }

        private void dgvAssignSubject_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;

          textSubjectId.Text = dgvAssignSubject.Rows[rowIndex].Cells[0].Value.ToString();

           textUserId.Text = dgvAssignSubject.Rows[rowIndex].Cells[2].Value.ToString();

           
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            String keyword = textSearch.Text;

            SqlConnection conn = new SqlConnection(myconnstring);

            SqlDataAdapter sda = new SqlDataAdapter("select s.id subjectid,s.subjectname,u.id userid, u.username from users u join user_subject us on u.id = us.userid join Subject s on s.id = us.subjectid WHERE u.id LIKE '%" + keyword + "%' or  s.id LIKE '%" + keyword + "%' or s.subjectname LIKE '%" + keyword + "%' or u.name LIKE '%" + keyword + "%'  ", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvAssignSubject.DataSource = dt;
        }
    }
}
