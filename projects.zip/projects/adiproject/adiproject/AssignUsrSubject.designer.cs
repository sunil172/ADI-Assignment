﻿namespace adi.Classes
{
    partial class AssignUsrSubject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbSubjectName = new System.Windows.Forms.ComboBox();
            this.lblCourseName = new System.Windows.Forms.Label();
            this.textSearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.lblSubjectId = new System.Windows.Forms.Label();
            this.textSubjectId = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.dgvAssignSubject = new System.Windows.Forms.DataGridView();
            this.textUserId = new System.Windows.Forms.TextBox();
            this.lblUserId = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.listUserName = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssignSubject)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbSubjectName
            // 
            this.cmbSubjectName.FormattingEnabled = true;
            this.cmbSubjectName.Location = new System.Drawing.Point(179, 112);
            this.cmbSubjectName.Name = "cmbSubjectName";
            this.cmbSubjectName.Size = new System.Drawing.Size(175, 21);
            this.cmbSubjectName.TabIndex = 51;
            // 
            // lblCourseName
            // 
            this.lblCourseName.AutoSize = true;
            this.lblCourseName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourseName.ForeColor = System.Drawing.Color.Maroon;
            this.lblCourseName.Location = new System.Drawing.Point(29, 112);
            this.lblCourseName.Name = "lblCourseName";
            this.lblCourseName.Size = new System.Drawing.Size(144, 24);
            this.lblCourseName.TabIndex = 50;
            this.lblCourseName.Text = "Select Subject";
            // 
            // textSearch
            // 
            this.textSearch.Location = new System.Drawing.Point(412, 30);
            this.textSearch.Name = "textSearch";
            this.textSearch.Size = new System.Drawing.Size(537, 20);
            this.textSearch.TabIndex = 49;
            this.textSearch.TextChanged += new System.EventHandler(this.textSearch_TextChanged);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.ForeColor = System.Drawing.Color.Maroon;
            this.lblSearch.Location = new System.Drawing.Point(314, 30);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(76, 24);
            this.lblSearch.TabIndex = 48;
            this.lblSearch.Text = "Search";
            // 
            // lblSubjectId
            // 
            this.lblSubjectId.AutoSize = true;
            this.lblSubjectId.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubjectId.ForeColor = System.Drawing.Color.Maroon;
            this.lblSubjectId.Location = new System.Drawing.Point(32, 157);
            this.lblSubjectId.Name = "lblSubjectId";
            this.lblSubjectId.Size = new System.Drawing.Size(103, 24);
            this.lblSubjectId.TabIndex = 47;
            this.lblSubjectId.Text = "Subject Id";
            // 
            // textSubjectId
            // 
            this.textSubjectId.Location = new System.Drawing.Point(179, 157);
            this.textSubjectId.Name = "textSubjectId";
            this.textSubjectId.Size = new System.Drawing.Size(175, 20);
            this.textSubjectId.TabIndex = 46;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.BurlyWood;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(439, 306);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(158, 36);
            this.btnClear.TabIndex = 45;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Red;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(232, 306);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(158, 36);
            this.btnDelete.TabIndex = 44;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.BackColor = System.Drawing.Color.Maroon;
            this.btnCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreate.ForeColor = System.Drawing.Color.White;
            this.btnCreate.Location = new System.Drawing.Point(36, 306);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(158, 36);
            this.btnCreate.TabIndex = 42;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = false;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // dgvAssignSubject
            // 
            this.dgvAssignSubject.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAssignSubject.Location = new System.Drawing.Point(578, 67);
            this.dgvAssignSubject.Name = "dgvAssignSubject";
            this.dgvAssignSubject.Size = new System.Drawing.Size(371, 233);
            this.dgvAssignSubject.TabIndex = 41;
            this.dgvAssignSubject.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvAssignSubject_RowHeaderMouseClick);
            // 
            // textUserId
            // 
            this.textUserId.Location = new System.Drawing.Point(179, 210);
            this.textUserId.Name = "textUserId";
            this.textUserId.Size = new System.Drawing.Size(175, 20);
            this.textUserId.TabIndex = 40;
            // 
            // lblUserId
            // 
            this.lblUserId.AutoSize = true;
            this.lblUserId.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserId.ForeColor = System.Drawing.Color.Maroon;
            this.lblUserId.Location = new System.Drawing.Point(32, 210);
            this.lblUserId.Name = "lblUserId";
            this.lblUserId.Size = new System.Drawing.Size(76, 24);
            this.lblUserId.TabIndex = 39;
            this.lblUserId.Text = "User Id";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.Color.Maroon;
            this.lblUserName.Location = new System.Drawing.Point(396, 107);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(114, 24);
            this.lblUserName.TabIndex = 52;
            this.lblUserName.Text = "User Name";
            // 
            // listUserName
            // 
            this.listUserName.FormattingEnabled = true;
            this.listUserName.Location = new System.Drawing.Point(391, 135);
            this.listUserName.Name = "listUserName";
            this.listUserName.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listUserName.Size = new System.Drawing.Size(149, 160);
            this.listUserName.TabIndex = 53;
            // 
            // AssignUsrSubject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 373);
            this.Controls.Add(this.listUserName);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.cmbSubjectName);
            this.Controls.Add(this.lblCourseName);
            this.Controls.Add(this.textSearch);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.lblSubjectId);
            this.Controls.Add(this.textSubjectId);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.dgvAssignSubject);
            this.Controls.Add(this.textUserId);
            this.Controls.Add(this.lblUserId);
            this.Name = "AssignUsrSubject";
            this.Text = "AssignUsrSubject";
            this.Load += new System.EventHandler(this.AssignUsrSubject_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssignSubject)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbSubjectName;
        private System.Windows.Forms.Label lblCourseName;
        private System.Windows.Forms.TextBox textSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Label lblSubjectId;
        private System.Windows.Forms.TextBox textSubjectId;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.DataGridView dgvAssignSubject;
        private System.Windows.Forms.TextBox textUserId;
        private System.Windows.Forms.Label lblUserId;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.ListBox listUserName;
    }
}