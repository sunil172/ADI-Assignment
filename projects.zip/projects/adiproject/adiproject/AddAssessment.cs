﻿using adi.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adi
{
    public partial class AddAssessment : Form
    {
        public AddAssessment()
        {
            InitializeComponent();
          
        }



        private void AddAssessment_Load(object sender, EventArgs e)
        {
            SubjectName();
            DataTable dt = c.Select();
            dgvAssessment.DataSource = dt;
        }

        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
        public void SubjectName()
        {
            cmbSubjectName.Items.Clear();
            DataSet ds = new DataSet();
            ds.Clear();
            //Connection String
            SqlConnection conn = new SqlConnection(myconnstring);

            conn.Open();
            SqlDataAdapter adpi = new SqlDataAdapter("Select distinct id,subjectname from Subject", conn);
            adpi.Fill(ds);
            cmbSubjectName.DataSource = ds.Tables[0];
            cmbSubjectName.DisplayMember = "subjectname";
            cmbSubjectName.ValueMember = "id";
            conn.Close();
        }



        Assessment c = new Assessment();
        private void btnCreate_Click(object sender, EventArgs e)
        {
            c.assessmentname = textAssessmentName.Text;
            c.subjectid = int.Parse(cmbSubjectName.SelectedValue.ToString());


            bool success = c.Insert(c);
            if (success == true)
            {
                MessageBox.Show("Assessment Added Successfully");
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To Add Assessment");

            }

            DataTable dt = c.Select();
            dgvAssessment.DataSource = dt;


        }
        public void Clear()
        {

            textAssessmentName.Text = "";
            textAssessmentId.Text = "";
            cmbSubjectName.Text = "";


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            c.assessmentid = int.Parse(textAssessmentId.Text);
            c.assessmentname = textAssessmentName.Text;
            c.subjectid = int.Parse(cmbSubjectName.SelectedValue.ToString());


            bool success = c.Update(c);
            if (success == true)
            {
                MessageBox.Show("Assessment updated Successfully");
                DataTable dt = c.Select();
                dgvAssessment.DataSource = dt;
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To update Assessment");

            }

        }

        private void dgvAssessment_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;

            cmbSubjectName.Text = dgvAssessment.Rows[rowIndex].Cells[3].Value.ToString();

            textAssessmentName.Text = dgvAssessment.Rows[rowIndex].Cells[1].Value.ToString();

            textAssessmentId.Text = dgvAssessment.Rows[rowIndex].Cells[0].Value.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            c.assessmentid = int.Parse(textAssessmentId.Text);
            bool success = c.Delete(c);

            if (success == true)
            {
                MessageBox.Show("Assessment Deleted Successfully");
                DataTable dt = c.Select();
                dgvAssessment.DataSource = dt;
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To Delete Subject");

            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            String keyword = textSearch.Text;

            SqlConnection conn = new SqlConnection(myconnstring);

            SqlDataAdapter sda = new SqlDataAdapter("select a.id as assessmentid,a.assessmentname,s.id as subjectid,s.subjectname from assessment a join subject s on a.subjectid=s.id WHERE a.id LIKE '%" + keyword + "%' or s.subjectname LIKE '%" + keyword + "%' or a.assessmentname LIKE '%" + keyword + "%'  or s.id LIKE '%" + keyword + "%'", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvAssessment.DataSource = dt;
        }
    }
}
