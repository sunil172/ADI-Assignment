﻿using adi.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adi
{
    public partial class AddCourse : Form
    {
        public AddCourse()
        {
            InitializeComponent();
        }

       Course c = new Course();
        private void btnCreate_Click(object sender, EventArgs e)
        {
            c.coursename = textCoursename.Text;


            bool success = c.Insert(c);
            if (success == true)
            {
                MessageBox.Show("Course Added Successfully");
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To Add Course");

            }

            DataTable dt = c.Select();
            dgvCourse.DataSource = dt;


        }
        public void Clear()
        {

            textCoursename.Text = "";
            textCourseId.Text = "";
           

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
             c.courseid = int.Parse(textCourseId.Text);
            c.coursename = textCoursename.Text;
           

            bool success = c.Update(c);
            if (success == true)
            {
                MessageBox.Show("Subject updated Successfully");
                DataTable dt = c.Select();
                dgvCourse.DataSource = dt;
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To update Subject");

            }
        }

        private void dgvCourse_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;

            textCoursename.Text = dgvCourse.Rows[rowIndex].Cells[1].Value.ToString();
            
            textCourseId.Text = dgvCourse.Rows[rowIndex].Cells[0].Value.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            c.courseid = int.Parse(textCourseId.Text);
            bool success = c.Delete(c);

            if (success == true)
            {
                MessageBox.Show("SUbject Deleted Successfully");
                DataTable dt = c.Select();
                dgvCourse.DataSource = dt;
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To Delete Subject");

            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void AddCourse_Load(object sender, EventArgs e)
        {
            DataTable dt = c.Select();
            dgvCourse.DataSource = dt;
        }

        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            String keyword = textSearch.Text;

            SqlConnection conn = new SqlConnection(myconnstring);

            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Course WHERE id LIKE '%" + keyword + "%' or coursename LIKE '%" + keyword + "%' ", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvCourse.DataSource = dt;
        }
    }
}
