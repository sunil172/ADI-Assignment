﻿using adi.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adi
{
    public partial class AddSubject : Form
    {
        public AddSubject()
        {
            InitializeComponent();
        }

        Subject c = new Subject();
        private void btnCreate_Click(object sender, EventArgs e)
        {
            c.subjectname = textSubjectname.Text;
            c.courseid = int.Parse(cmbCourseName.SelectedValue.ToString());


            bool success = c.Insert(c);
            if (success == true)
            {
                MessageBox.Show("Subject Added Successfully");
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To Add Subject");

            }

            DataTable dt = c.Select();
            dgvSubject.DataSource = dt;


        }
        public void Clear()
        {

            textSubjectname.Text = "";
            textSubjectId.Text = "";
            cmbCourseName.Text = "";


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            c.subjectid = int.Parse(textSubjectId.Text);
            c.subjectname = textSubjectname.Text;
            c.courseid = int.Parse(cmbCourseName.SelectedValue.ToString());


            bool success = c.Update(c);
            if (success == true)
            {
                MessageBox.Show("Subject updated Successfully");
                DataTable dt = c.Select();
                dgvSubject.DataSource = dt;
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To update Subject");

            }
        }

        private void dgvSubject_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;

            textSubjectname.Text = dgvSubject.Rows[rowIndex].Cells[1].Value.ToString();

            cmbCourseName.Text= dgvSubject.Rows[rowIndex].Cells[2].Value.ToString();

            textSubjectId.Text = dgvSubject.Rows[rowIndex].Cells[0].Value.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            c.subjectid = int.Parse(textSubjectId.Text);
            bool success = c.Delete(c);

            if (success == true)
            {
                MessageBox.Show("Subject Deleted Successfully");
                DataTable dt = c.Select();
                dgvSubject.DataSource = dt;
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To Delete Subject");

            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void AddSubject_Load(object sender, EventArgs e)
        {
            DataTable dt = c.Select();
            dgvSubject.DataSource = dt;
        }

        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            String keyword = textSearch.Text;

            SqlConnection conn = new SqlConnection(myconnstring);

            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Subject WHERE id LIKE '%" + keyword + "%' or subjectname LIKE '%" + keyword + "%'  ", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvSubject.DataSource = dt;
        }

        public void CourseName()
        {
            cmbCourseName.Items.Clear();
            DataSet ds = new DataSet();
            ds.Clear();
            //Connection String
            SqlConnection conn = new SqlConnection(myconnstring);
            
            conn.Open();
            SqlDataAdapter adpi = new SqlDataAdapter("Select distinct id,coursename from Course", conn);
            adpi.Fill(ds);
            cmbCourseName.DataSource = ds.Tables[0];
            cmbCourseName.DisplayMember = "coursename";
            cmbCourseName.ValueMember = "id";
            conn.Close();
        }

        private void AddSubject_Load_1(object sender, EventArgs e)
        {
            CourseName();
            DataTable dt = c.Select();
            dgvSubject.DataSource = dt;
        }


    }
}
