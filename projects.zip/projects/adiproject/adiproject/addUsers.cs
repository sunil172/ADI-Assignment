﻿using adi.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adi
{
    public partial class addUsers : Form
    {
        public addUsers()
        {


            InitializeComponent();
        }

        UserClass c = new UserClass();

        private void addUsers_Load(object sender, EventArgs e)
        {

            DataTable dt = c.Select();
            dgvUsers.DataSource = dt;

        }

        private void btnCreateUsr_Click(object sender, EventArgs e)
        {
            c.name = textName.Text;
            c.address = textAddress.Text;
            c.username = textUsername.Text;
            c.password = textPassword.Text;
            c.role = cmbRole.Text;

            bool success = c.Insert(c);
            if (success == true)
            {
                MessageBox.Show("User Added Successfully");
                Clear();

            }

            else {

                MessageBox.Show("Failed To Add Users");

            }

            DataTable dt=c.Select();
            dgvUsers.DataSource = dt;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {

            Clear();

        }

        public void Clear() {

            textName.Text = "";
            textAddress.Text = "";
            textUsername.Text = "";
            textPassword.Text = "";
            cmbRole.Text = "";
            textUserId.Text = "";

        }

        private void dgvUsers_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            // Get the data from Data Grid View and Load it to the textboxes respicitively
            // identigy  the row on which mouse is clicked 

            int rowIndex = e.RowIndex;

            textName.Text = dgvUsers.Rows[rowIndex].Cells[1].Value.ToString();
            textAddress.Text = dgvUsers.Rows[rowIndex].Cells[2].Value.ToString(); 
            textUsername.Text = dgvUsers.Rows[rowIndex].Cells[4].Value.ToString(); 
            textPassword.Text = dgvUsers.Rows[rowIndex].Cells[5].Value.ToString(); 
            cmbRole.Text = dgvUsers.Rows[rowIndex].Cells[3].Value.ToString();
            textUserId.Text = dgvUsers.Rows[rowIndex].Cells[0].Value.ToString();




        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            c.userid = int.Parse(textUserId.Text);
            c.name = textName.Text;
            c.address = textAddress.Text;
            c.username = textUsername.Text;
            c.password = textPassword.Text;
            c.role = cmbRole.Text;

            bool success = c.Update(c);
            if (success == true)
            {
                MessageBox.Show("User updated Successfully");
                DataTable dt = c.Select();
                dgvUsers.DataSource = dt;
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To update Users");

            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            c.userid = int.Parse(textUserId.Text);
            bool success = c.Delete(c);

            if (success == true)
            {
                MessageBox.Show("User Deleted Successfully");
                DataTable dt = c.Select();
                dgvUsers.DataSource = dt;
                Clear();

            }

            else
            {

                MessageBox.Show("Failed To Delete Users");

            }

        }
        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            String keyword = textSearch.Text;

            SqlConnection conn = new SqlConnection(myconnstring);

            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM USERS WHERE id LIKE '%" + keyword + "%' or name LIKE '%" + keyword + "%' or address LIKE '%" + keyword + "%' or role LIKE '%" + keyword + "%' ", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvUsers.DataSource = dt;
        }
    }
}
