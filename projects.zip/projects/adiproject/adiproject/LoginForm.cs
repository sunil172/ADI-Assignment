﻿using adi;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adiproject
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
            SqlConnection conn = new SqlConnection(myconnstring);

            conn.Open();
           SqlCommand cmd = new SqlCommand("select * from users where username=@username and password=@password", conn);
       
            cmd.Parameters.AddWithValue("@username", textUsername.Text.ToString());
            cmd.Parameters.AddWithValue("@password", textPassword.Text.ToString());
          SqlDataReader  reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                if (reader["Password"].ToString().Equals(textPassword.Text.ToString(), StringComparison.InvariantCulture))
                {
                    int userid = int.Parse(reader["id"].ToString());

                    String role = reader["role"].ToString();

                  //  Application.Run(new mainForm(userid, role));

                    mainForm f = new mainForm(userid,role);
                    f.Visible = true;
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("invalid credential");
                }
            }
            else
            {
                MessageBox.Show("no connection");
            }
            reader.Close();
            cmd.Dispose();
            conn.Close();


        }
    }
}
