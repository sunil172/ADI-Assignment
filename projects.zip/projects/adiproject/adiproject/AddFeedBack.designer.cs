﻿namespace adi
{
    partial class AddFeedBack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbAssessmentName = new System.Windows.Forms.ComboBox();
            this.lblAssessmentName = new System.Windows.Forms.Label();
            this.textSearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.lblFeedbackId = new System.Windows.Forms.Label();
            this.textfeedbackid = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.dgvFeedback = new System.Windows.Forms.DataGridView();
            this.lblFeesbackName = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.cmbUserName = new System.Windows.Forms.ComboBox();
            this.textFeedback = new System.Windows.Forms.TextBox();
            this.lblGrade = new System.Windows.Forms.Label();
            this.cmbGrade = new System.Windows.Forms.ComboBox();
            this.textPrivateNote = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeedback)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbAssessmentName
            // 
            this.cmbAssessmentName.FormattingEnabled = true;
            this.cmbAssessmentName.Location = new System.Drawing.Point(215, 208);
            this.cmbAssessmentName.Name = "cmbAssessmentName";
            this.cmbAssessmentName.Size = new System.Drawing.Size(175, 21);
            this.cmbAssessmentName.TabIndex = 64;
            this.cmbAssessmentName.SelectionChangeCommitted += new System.EventHandler(this.cmbAssessmentName_SelectionChangeCommitted);
            // 
            // lblAssessmentName
            // 
            this.lblAssessmentName.AutoSize = true;
            this.lblAssessmentName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssessmentName.ForeColor = System.Drawing.Color.Maroon;
            this.lblAssessmentName.Location = new System.Drawing.Point(25, 205);
            this.lblAssessmentName.Name = "lblAssessmentName";
            this.lblAssessmentName.Size = new System.Drawing.Size(186, 24);
            this.lblAssessmentName.TabIndex = 63;
            this.lblAssessmentName.Text = "Select Assessment";
            // 
            // textSearch
            // 
            this.textSearch.Location = new System.Drawing.Point(405, 33);
            this.textSearch.Name = "textSearch";
            this.textSearch.Size = new System.Drawing.Size(537, 20);
            this.textSearch.TabIndex = 62;
            this.textSearch.TextChanged += new System.EventHandler(this.textSearch_TextChanged);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.ForeColor = System.Drawing.Color.Maroon;
            this.lblSearch.Location = new System.Drawing.Point(307, 33);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(76, 24);
            this.lblSearch.TabIndex = 61;
            this.lblSearch.Text = "Search";
            // 
            // lblFeedbackId
            // 
            this.lblFeedbackId.AutoSize = true;
            this.lblFeedbackId.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFeedbackId.ForeColor = System.Drawing.Color.Maroon;
            this.lblFeedbackId.Location = new System.Drawing.Point(21, 71);
            this.lblFeedbackId.Name = "lblFeedbackId";
            this.lblFeedbackId.Size = new System.Drawing.Size(126, 24);
            this.lblFeedbackId.TabIndex = 60;
            this.lblFeedbackId.Text = "Feedback Id";
            // 
            // textfeedbackid
            // 
            this.textfeedbackid.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textfeedbackid.Location = new System.Drawing.Point(215, 75);
            this.textfeedbackid.Name = "textfeedbackid";
            this.textfeedbackid.Size = new System.Drawing.Size(168, 20);
            this.textfeedbackid.TabIndex = 59;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.BurlyWood;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(214, 309);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(158, 36);
            this.btnClear.TabIndex = 58;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Teal;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.Location = new System.Drawing.Point(750, 328);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(158, 36);
            this.btnUpdate.TabIndex = 56;
            this.btnUpdate.Text = "Add Private Note";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Visible = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.BackColor = System.Drawing.Color.Maroon;
            this.btnCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreate.ForeColor = System.Drawing.Color.White;
            this.btnCreate.Location = new System.Drawing.Point(29, 309);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(158, 36);
            this.btnCreate.TabIndex = 55;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = false;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // dgvFeedback
            // 
            this.dgvFeedback.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFeedback.Location = new System.Drawing.Point(405, 70);
            this.dgvFeedback.Name = "dgvFeedback";
            this.dgvFeedback.Size = new System.Drawing.Size(537, 233);
            this.dgvFeedback.TabIndex = 54;
            this.dgvFeedback.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvFeedback_RowHeaderMouseClick);
            // 
            // lblFeesbackName
            // 
            this.lblFeesbackName.AutoSize = true;
            this.lblFeesbackName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFeesbackName.ForeColor = System.Drawing.Color.Maroon;
            this.lblFeesbackName.Location = new System.Drawing.Point(25, 157);
            this.lblFeesbackName.Name = "lblFeesbackName";
            this.lblFeesbackName.Size = new System.Drawing.Size(103, 24);
            this.lblFeesbackName.TabIndex = 52;
            this.lblFeesbackName.Text = "Feedback";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.ForeColor = System.Drawing.Color.Maroon;
            this.lblUser.Location = new System.Drawing.Point(25, 246);
            this.lblUser.Name = "lblUser";
            this.lblUser.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblUser.Size = new System.Drawing.Size(145, 24);
            this.lblUser.TabIndex = 65;
            this.lblUser.Text = "Select Student";
            // 
            // cmbUserName
            // 
            this.cmbUserName.FormattingEnabled = true;
            this.cmbUserName.Location = new System.Drawing.Point(215, 251);
            this.cmbUserName.Name = "cmbUserName";
            this.cmbUserName.Size = new System.Drawing.Size(175, 21);
            this.cmbUserName.TabIndex = 66;
            // 
            // textFeedback
            // 
            this.textFeedback.Location = new System.Drawing.Point(214, 141);
            this.textFeedback.Multiline = true;
            this.textFeedback.Name = "textFeedback";
            this.textFeedback.Size = new System.Drawing.Size(175, 61);
            this.textFeedback.TabIndex = 53;
            // 
            // lblGrade
            // 
            this.lblGrade.AutoSize = true;
            this.lblGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrade.ForeColor = System.Drawing.Color.Maroon;
            this.lblGrade.Location = new System.Drawing.Point(25, 105);
            this.lblGrade.Name = "lblGrade";
            this.lblGrade.Size = new System.Drawing.Size(67, 24);
            this.lblGrade.TabIndex = 67;
            this.lblGrade.Text = "Grade";
            // 
            // cmbGrade
            // 
            this.cmbGrade.FormattingEnabled = true;
            this.cmbGrade.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D",
            "E"});
            this.cmbGrade.Location = new System.Drawing.Point(214, 108);
            this.cmbGrade.Name = "cmbGrade";
            this.cmbGrade.Size = new System.Drawing.Size(175, 21);
            this.cmbGrade.TabIndex = 68;
            // 
            // textPrivateNote
            // 
            this.textPrivateNote.Location = new System.Drawing.Point(405, 318);
            this.textPrivateNote.Multiline = true;
            this.textPrivateNote.Name = "textPrivateNote";
            this.textPrivateNote.Size = new System.Drawing.Size(339, 61);
            this.textPrivateNote.TabIndex = 69;
            this.textPrivateNote.Visible = false;
            // 
            // AddFeedBack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(966, 399);
            this.Controls.Add(this.textPrivateNote);
            this.Controls.Add(this.cmbGrade);
            this.Controls.Add(this.lblGrade);
            this.Controls.Add(this.cmbUserName);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.cmbAssessmentName);
            this.Controls.Add(this.lblAssessmentName);
            this.Controls.Add(this.textSearch);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.lblFeedbackId);
            this.Controls.Add(this.textfeedbackid);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.dgvFeedback);
            this.Controls.Add(this.textFeedback);
            this.Controls.Add(this.lblFeesbackName);
            this.Name = "AddFeedBack";
            this.Text = "AddFeedBack";
            this.Load += new System.EventHandler(this.AddFeedBack_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeedback)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbAssessmentName;
        private System.Windows.Forms.Label lblAssessmentName;
        private System.Windows.Forms.TextBox textSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Label lblFeedbackId;
        private System.Windows.Forms.TextBox textfeedbackid;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.DataGridView dgvFeedback;
        private System.Windows.Forms.Label lblFeesbackName;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.ComboBox cmbUserName;
        private System.Windows.Forms.TextBox textFeedback;
        private System.Windows.Forms.Label lblGrade;
        private System.Windows.Forms.ComboBox cmbGrade;
        private System.Windows.Forms.TextBox textPrivateNote;
    }
}