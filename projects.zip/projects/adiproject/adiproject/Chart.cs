﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adi
{
    public partial class Chart : Form
    {
        int byuserid;
        public Chart(int byuserid)
        {
            this.byuserid = byuserid;
            InitializeComponent();
        }

        private void gradeChart_Click(object sender, EventArgs e)
        {
            loadchart();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            loadchart();
        }
        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;

        public void loadchart() {

            SqlConnection conn = new SqlConnection(myconnstring);

            conn.Open();
            String sql= "select count(distinct touserid) as count, grade from feedbacks  group by grade";
            SqlCommand cmd = new SqlCommand(sql, conn);
           
            SqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                // Add X and Y values using AddXY() method  
                this.gradeChart.Series["Students"].Points.AddXY(rdr["grade"].ToString(),rdr["count"]);
            }
        }

        private void Chart_Load(object sender, EventArgs e)
        {
            loadchart();

        }
    }
}
