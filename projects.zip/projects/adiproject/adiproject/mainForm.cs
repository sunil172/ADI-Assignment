﻿using adi.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adi
{
    public partial class mainForm : Form
    {
        int byuserid;
        String role;
        public mainForm(int byuserid,String role)
        {
            this.role = role;
            this.byuserid = byuserid;
            InitializeComponent();
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            addUsers u = new addUsers();
            u.Visible = true;
        }

        private void btnAddCourse_Click(object sender, EventArgs e)
        {
            AddCourse c = new AddCourse();
            c.Visible = true;
        }

        private void btnAddSubject_Click(object sender, EventArgs e)
        {
            AddSubject c = new AddSubject();
            c.Visible = true;
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            AssignUsrSubject c = new AssignUsrSubject();
            c.Visible = true;
        }

        private void btnAddAssement_Click(object sender, EventArgs e)
        {
            AddAssessment c = new AddAssessment();
            c.Visible= true;
        }

        private void btnFeedback_Click(object sender, EventArgs e)
        {
            AddFeedBack c = new AddFeedBack(byuserid, role);
            c.Visible = true;
        }

        private void btnChart_Click(object sender, EventArgs e)
        {
            Chart c = new Chart(byuserid);
            c.Visible = true;
        }

        private void btnWordCloud_Click(object sender, EventArgs e)
        {
             string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
            SqlConnection conn = new SqlConnection(myconnstring);

            conn.Open();
            String sql = "select feedback from feedbacks";
            SqlCommand cmd = new SqlCommand(sql, conn);

            SqlDataReader rdr = cmd.ExecuteReader();
            StringBuilder b = new StringBuilder();


            while (rdr.Read())
            {
                // Add X and Y values using AddXY() method  
                b.Append(rdr["feedback"]);
                b.Append(" ");
                //MessageBox.Show(b.ToString());
            }
            ControlDemoApp.MainForm c = new ControlDemoApp.MainForm(b.ToString());
            c.Visible = true;
            c.Show();
           
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            if (role.Equals("Student"))
            {
                btnAddAssement.Visible = false;
                btnAddCourse.Visible = false;
                btnAddSubject.Visible = false;
                btnAddUser.Visible = false;
                btnAssign.Visible = false;
                btnChart.Visible = false;
                btnWordCloud.Visible = false;

            }
            else if (role.Equals("Staff"))
            {
                btnAddAssement.Visible = false;
                btnAddCourse.Visible = false;
                btnAddSubject.Visible = false;


            }
            else { }
        }
    }
}
