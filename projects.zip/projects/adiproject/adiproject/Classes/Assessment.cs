﻿using adi.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adi.Classes
{
    class Assessment
    {
        //getter and setter properties
        public String assessmentname { get; set; }
        public int assessmentid { get; set; }
        public String subjectname { get; set; }
        public int subjectid { get; set; }

        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;

        // selecting User Data from Database
        public DataTable Select()
        {

            SqlConnection conn = new SqlConnection(myconnstring);
            DataTable dt = new DataTable();

            try
            {
                String sql = "select a.id as assessmentid,a.assessmentname,s.id as subjectid,s.subjectname from assessment a join subject s on a.subjectid=s.id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                conn.Open();
                adapter.Fill(dt);

            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return dt;
        }

        //inserting Data into database

        public bool Insert(Assessment c)
        {

            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);
            try
            {

                String sql = "INSERT INTO assessment(assessmentname,subjectid) Values (@assessmentname,@subjectid)";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@assessmentname", c.assessmentname);
                cmd.Parameters.AddWithValue("@subjectid", c.subjectid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }


        //update data ind atabase

        public bool Update(Assessment c)
        {

            bool isSuccess = false;
            SqlConnection conn = new SqlConnection(myconnstring);

            try
            {
                String sql = "UPDATE assessment SET assessmentname=@assessmentname, subjectid=@subjectid where id=@assessmentid";

                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@assessmentname", c.assessmentname);
                cmd.Parameters.AddWithValue("@subjectid", c.subjectid);
                cmd.Parameters.AddWithValue("@assessmentid", c.assessmentid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ee) { }
            finally
            {
                conn.Close();

            }

            return isSuccess;

        }

        public bool Delete(Assessment c)
        {
            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);

            try
            {

                String sql = "DELETE FROM assessment WHERE id=@assessmentid";

                //creating sql command

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@assessmentid", c.assessmentid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }

            return isSuccess;

        }
    }
}
