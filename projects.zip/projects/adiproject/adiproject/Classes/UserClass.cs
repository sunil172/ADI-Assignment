﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adi.Classes
{
    class UserClass
    {

        //getter and setter properties
        public String name { get; set; }
        public String address { get; set; }
        public String username { get; set; }
        public String password { get; set; }
        public String role { get; set; }
        public int userid { get; set; }

        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;

        // selecting User Data from Database
        public DataTable Select() {

            SqlConnection conn = new SqlConnection(myconnstring);
            DataTable dt = new DataTable();

            try {
                String sql = "SELECT * FROM users";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                conn.Open();
                adapter.Fill(dt);

            }
            catch (Exception ex) {

            }
            finally {
                conn.Close();
            }
            return dt;
        }

        //inserting Data into database

        public bool Insert(UserClass c) {

            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);
            try {

                String sql = "INSERT INTO USERS(name,address,username,password,role) Values (@name,@address,@username,@password,@role)";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@name", c.name);
                cmd.Parameters.AddWithValue("@address", c.address);
                cmd.Parameters.AddWithValue("@username", c.username);
                cmd.Parameters.AddWithValue("@password", c.password);
                cmd.Parameters.AddWithValue("@role", c.role);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;

                }
                else {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }
            finally {
                conn.Close();
            }

            return isSuccess;
        }


        //update data ind atabase

        public bool Update(UserClass c) {

            bool isSuccess = false;
            SqlConnection conn = new SqlConnection(myconnstring);

            try {
                String sql = "UPDATE USERS SET name=@name, address=@address, username=@username, password=@password , role=@role where id=@userid";

                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@name", c.name);
                cmd.Parameters.AddWithValue("@address", c.address);
                cmd.Parameters.AddWithValue("@username", c.username);
                cmd.Parameters.AddWithValue("@password", c.password);
                cmd.Parameters.AddWithValue("@role", c.role);
                cmd.Parameters.AddWithValue("@userid", c.userid);

                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ee) { }
            finally { conn.Close();

            }

            return isSuccess;

        }

        public bool Delete(UserClass c)
        {
            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);

            try {

                String sql = "DELETE FROM USERS WHERE id=@userid";

                //creating sql command

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@userid",c.userid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }

            return isSuccess;

        }

    }
}
