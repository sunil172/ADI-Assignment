﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adi.Classes
{
    class Subject
    {

        //getter and setter properties
        public String subjectname { get; set; }
        public int subjectid { get; set; }
        public String coursename { get; set; }
        public int courseid { get; set; } 

        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;

        // selecting User Data from Database
        public DataTable Select()
        {

            SqlConnection conn = new SqlConnection(myconnstring);
            DataTable dt = new DataTable();

            try
            {
                String sql = "SELECT s.id,s.subjectname,c.coursename,c.id as course_id FROM Subject s join course c on s.course_id=c.id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                conn.Open();
                adapter.Fill(dt);

            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return dt;
        }

        //inserting Data into database

        public bool Insert(Subject c)
        {

            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);
            try
            {

                String sql = "INSERT INTO Subject(subjectname,course_id) Values (@subjectname,@courseid)";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@subjectname", c.subjectname);
                cmd.Parameters.AddWithValue("@courseid", c.courseid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }


        //update data ind atabase

        public bool Update(Subject c)
        {

            bool isSuccess = false;
            SqlConnection conn = new SqlConnection(myconnstring);

            try
            {
                String sql = "UPDATE Subject SET subjectname=@subjectname, course_id=@courseid where id=@subjectid";

                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@subjectname", c.subjectname);
                cmd.Parameters.AddWithValue("@subjectid", c.subjectid);
                cmd.Parameters.AddWithValue("@courseid", c.courseid);

                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ee) { }
            finally
            {
                conn.Close();

            }

            return isSuccess;

        }

        public bool Delete(Subject c)
        {
            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);

            try
            {

                String sql = "DELETE FROM Subject WHERE id=@subjectid";

                //creating sql command

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@subjectid", c.subjectid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }

            return isSuccess;

        }
    }
}
