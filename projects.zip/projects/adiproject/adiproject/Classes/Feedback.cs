﻿using adi.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adi.Classes
{
    class Feedback
    {
        //getter and setter properties
        public String assessmentname { get; set; }
        public int assessmentid { get; set; }
        public String feedback { get; set; }
        public int feedbackid { get; set; }
        public String grade { get; set; }
        public String privatenote { get; set; }
        public int touserid { get; set; }
        public int byuserid { get; set; }

        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;

        // selecting User Data from Database
        public DataTable Select(int userid)
        {

            SqlConnection conn = new SqlConnection(myconnstring);
            DataTable dt = new DataTable();

            try
            {
                String sql = "select f.id,f.feedback,f.grade,f.privatenote,f.touserid,u.id touserid,u.name StudentName,b.id byuserid,b.name,a.id assessmentid,a.assessmentname Byuser from feedbacks f join users u on f.touserid=u.id join users b on f.byuserid=b.id join assessment a on f.assessmentid=a.id where f.touserid="+userid+" or f.byuserid="+userid;
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                conn.Open();
                adapter.Fill(dt);

            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return dt;
        }

        //inserting Data into database

        public bool Insert(Feedback c)
        {

            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);
            try
            {

                String sql = "INSERT INTO feedbacks(feedback,grade,touserid,assessmentid,byuserid) Values (@feedback,@grade,@touserid,@assessmentid,@byuserid)";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@feedback", c.feedback);
                cmd.Parameters.AddWithValue("@grade", c.grade);
                cmd.Parameters.AddWithValue("@touserid", c.touserid);
                cmd.Parameters.AddWithValue("@byuserid", c.byuserid);
                cmd.Parameters.AddWithValue("@assessmentid", c.assessmentid);

                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }


        //update data ind atabase

        public bool Update(Feedback c)
        {

            bool isSuccess = false;
            SqlConnection conn = new SqlConnection(myconnstring);

            try
            {
                String sql = "UPDATE feedbacks SET privatenote=@privatenote where id=@feedbackid";

                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@privatenote", c.privatenote);
                cmd.Parameters.AddWithValue("@feedbackid", c.feedbackid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;


                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ee) { }
            finally
            {
                conn.Close();

            }

            return isSuccess;

        }

        public bool Delete(Assessment c)
        {
            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);

            try
            {

                String sql = "DELETE FROM assessment WHERE id=@assessmentid";

                //creating sql command

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@assessmentid", c.assessmentid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }

            return isSuccess;

        }
    }
}
