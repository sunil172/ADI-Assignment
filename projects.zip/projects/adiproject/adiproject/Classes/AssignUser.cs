﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adi.Classes
{
    class AssignUser
    {
        //getter and setter properties
        public String subjectname { get; set; }
        public int subjectid { get; set; }
        public String username { get; set; }
        public int userid { get; set; }

        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;

        // selecting User Data from Database
        public DataTable Select()
        {

            SqlConnection conn = new SqlConnection(myconnstring);
            DataTable dt = new DataTable();

            try
            {
                String sql = "select s.id subjectid,s.subjectname,u.id userid, u.username from users u join user_subject us on u.id = us.userid join Subject s on s.id = us.subjectid; ";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                conn.Open();
                adapter.Fill(dt);

            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return dt;
        }

        //inserting Data into database

        public bool Insert(AssignUser c)
        {

            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);
            try
            {

                String sql = "INSERT INTO user_subject(userid,subjectid) Values (@userid,@subjectid)";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@userid", c.userid);
                cmd.Parameters.AddWithValue("@subjectid", c.subjectid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }


        //update data ind atabase

        

        public bool Delete(AssignUser c)
        {
            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);

            try
            {

                String sql = "DELETE FROM user_subject WHERE userid=@userid and subjectid=@subjectid";

                //creating sql command

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@subjectid", c.subjectid);
                cmd.Parameters.AddWithValue("@userid", c.userid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }

            return isSuccess;

        }
    }
}
