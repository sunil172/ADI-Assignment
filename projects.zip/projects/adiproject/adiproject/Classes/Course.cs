﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adi.Classes
{
    class Course
    {
        //getter and setter properties
        public String coursename { get; set; }
        public int courseid { get; set; }

        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;

        // selecting User Data from Database
        public DataTable Select()
        {

            SqlConnection conn = new SqlConnection(myconnstring);
            DataTable dt = new DataTable();

            try
            {
                String sql = "SELECT * FROM Course";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                conn.Open();
                adapter.Fill(dt);

            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return dt;
        }

        //inserting Data into database

        public bool Insert(Course c)
        {

            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);
            try
            {

                String sql = "INSERT INTO Course(coursename) Values (@coursename)";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@coursename", c.coursename);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }


        //update data ind atabase

        public bool Update(Course c)
        {

            bool isSuccess = false;
            SqlConnection conn = new SqlConnection(myconnstring);

            try
            {
                String sql = "UPDATE Course SET coursename=@coursename where id=@courseid";

                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@coursename", c.coursename);
                cmd.Parameters.AddWithValue("@courseid", c.courseid);

                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ee) { }
            finally
            {
                conn.Close();

            }

            return isSuccess;

        }

        public bool Delete(Course c)
        {
            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstring);

            try
            {

                String sql = "DELETE FROM Course WHERE id=@courseid";

                //creating sql command

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@courseid", c.courseid);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {

                    isSuccess = true;

                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ee) { }

            return isSuccess;

        }

    }
}

