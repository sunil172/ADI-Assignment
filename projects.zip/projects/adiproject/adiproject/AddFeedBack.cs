﻿using adi.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adi
{
    public partial class AddFeedBack : Form
    {
        int byuserid = 0;
        String role = null;
        public AddFeedBack(int byuserid,String role)
        {
            this.byuserid = byuserid;
            InitializeComponent();

            this.role = role;
            if (role.Equals("Student")) {
                textPrivateNote.Visible = true;
                btnUpdate.Visible = true;
                btnCreate.Visible = false;

            }
        }

        private void AddFeedBack_Load(object sender, EventArgs e)
        {
            AssessmentName(byuserid);
            DataTable dt = c.Select(byuserid);
            dgvFeedback.DataSource = dt;

        }


        static string myconnstring = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
        public void AssessmentName(int byuserid)
        {
            this.cmbAssessmentName.DataSource = null;
            for (int i = cmbAssessmentName.Items.Count - 1; i >= 0; i--)
            {
                cmbAssessmentName.Items.RemoveAt(i);
            }
           // cmbAssessmentName.Items.Clear();
            DataSet ds = new DataSet();
            ds.Clear();
            //Connection String
            SqlConnection conn = new SqlConnection(myconnstring);

            conn.Open();
            SqlDataAdapter adpi = new SqlDataAdapter("select distinct a.id as assessmentid,a.assessmentname from assessment a join subject s on a.subjectid=s.id join user_subject us on s.id=us.subjectid join users u on u.id=us.userid where u.id="+byuserid, conn);
            adpi.Fill(ds);
            cmbAssessmentName.DataSource = ds.Tables[0];
            cmbAssessmentName.DisplayMember = "assessmentname";
            cmbAssessmentName.ValueMember = "assessmentid";
            cmbAssessmentName.SelectedIndex = -1;
            conn.Close();
        }

        public void UserName(int assessmentid)
        {
            this.cmbUserName.DataSource = null;
            for (int i = cmbUserName.Items.Count - 1; i >= 0; i--)
            {
                cmbUserName.Items.RemoveAt(i);
            }
            DataSet ds = new DataSet();
            ds.Clear();
            //Connection String
            SqlConnection conn = new SqlConnection(myconnstring);

            conn.Open();
            SqlDataAdapter adpi = new SqlDataAdapter("select distinct u.id,u.name from assessment a join subject s on a.subjectid=s.id join user_subject us on s.id=us.subjectid join users u on u.id=us.userid where u.role='Student' and a.id=" + assessmentid, conn);
            adpi.Fill(ds);
            cmbUserName.DataSource = ds.Tables[0];
            cmbUserName.DisplayMember = "name";
            cmbUserName.ValueMember = "id";
            conn.Close();
        }

        private void cmbAssessmentName_SelectionChangeCommitted(object sender, EventArgs e)
        {

            if (cmbAssessmentName.SelectedIndex>=0) {

                int assessmentid = int.Parse(cmbAssessmentName.SelectedValue.ToString());

                UserName(assessmentid);

            } else {
              
            }

        }
        Feedback c = new Feedback();

        private void btnCreate_Click(object sender, EventArgs e)
        {
            c.feedback = textFeedback.Text;
            c.grade = cmbGrade.Text;

            c.touserid = int.Parse(cmbUserName.SelectedValue.ToString());
            c.byuserid = byuserid;
            c.assessmentid = int.Parse(cmbAssessmentName.SelectedValue.ToString());


            bool success = c.Insert(c);
            if (success == true)
            {
                MessageBox.Show("Feedback Added Successfully");
                clear();

            }

            else
            {

                MessageBox.Show("Failed To Add Feedback");

            }

            DataTable dt = c.Select(byuserid);
            dgvFeedback.DataSource = dt;
        }

        public void clear() {
            textFeedback.Text = "";
            cmbGrade.Text = "";
            cmbAssessmentName.Text = "";
            cmbUserName.Text = "";
            textPrivateNote.Text = "";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void dgvFeedback_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;

           
            textfeedbackid.Text = dgvFeedback.Rows[rowIndex].Cells[0].Value.ToString();
            cmbGrade.Text = dgvFeedback.Rows[rowIndex].Cells[2].Value.ToString();
            cmbAssessmentName.Text = dgvFeedback.Rows[rowIndex].Cells[10].Value.ToString();
            cmbUserName.Text = dgvFeedback.Rows[rowIndex].Cells[6].Value.ToString();
            textFeedback.Text = dgvFeedback.Rows[rowIndex].Cells[1].Value.ToString();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            c.feedbackid = int.Parse(textfeedbackid.Text);
            c.privatenote = textPrivateNote.Text;
            


            bool success = c.Update(c);
            if (success == true)
            {
                MessageBox.Show("Note updated Successfully");
                DataTable dt = c.Select(byuserid);
                dgvFeedback.DataSource = dt;
                clear();

            }

            else
            {

                MessageBox.Show("Failed To update Note");

            }

        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {

            String keyword = textSearch.Text;

            SqlConnection conn = new SqlConnection(myconnstring);

            SqlDataAdapter sda = new SqlDataAdapter("select f.id,f.feedback,f.grade,f.privatenote,f.touserid,u.id touserid,u.name StudentName,b.id byuserid,b.name,a.id assessmentid,a.assessmentname Byuser from feedbacks f join users u on f.touserid=u.id join users b on f.byuserid=b.id join assessment a on f.assessmentid=a.id where f.touserid=" + byuserid + " or f.byuserid=" + byuserid+" and ( f.id LIKE '%" + keyword + "%' or f.feedback LIKE '%" + keyword + "%' or a.assessmentname LIKE '%" + keyword + "%'  or f.grade LIKE '%" + keyword + "%'", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvFeedback.DataSource = dt;
        }
    }
}
